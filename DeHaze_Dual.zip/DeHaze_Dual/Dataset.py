import torch
import torchvision
from torch.utils import data
from torch.autograd import Variable
import cv2
import numpy as np
import os
import random

import math;
import cv2 as cv
import scipy.io as sio

##########################################################################
train_len = 500
class DatasetTrain(data.Dataset):
    def __init__(self, opt):
        TRoot   = np.array([''])
        # for file in os.listdir(opt.test_root):
        for index in range(1,train_len+1):
            file = str(index)
            TRoot = np.append(TRoot, opt.train_T + file + '.mat')

        self.TRoot = TRoot[1:]
        self.opt = opt
        self.len=len(self.TRoot)

    def transformImage(self,image):
        opt = self.opt
        image = torchvision.transforms.ToTensor()(image)
        Tensor= torch.FloatTensor if opt.device == 'cpu' else torch.cuda.FloatTensor
        image = Variable(image.type(Tensor))
        return image

    def __getitem__(self, index):
        W = 256
        H = 256
        mat = sio.loadmat(self.TRoot[index],verify_compressed_data_integrity=False)
        T = mat["t"].astype(np.float64)
        A = (mat["A"]).astype(np.float64)/255.0
        haze_I = mat["haze_I_E_0"].astype(np.float64)/255.0
        img_dehazed = (mat["Dehaze"]).astype(np.float64)/255.0

        Hig, Wid, C = haze_I.shape
        w_offset = random.randint(0, max(0, Wid - W - 1))
        h_offset = random.randint(0, max(0, Hig - H - 1))

        src = haze_I[h_offset:h_offset + H, w_offset:w_offset + W, :]
        mid = img_dehazed[h_offset:h_offset + H, w_offset:w_offset + W, :]
        t = T[h_offset:h_offset + H, w_offset:w_offset + W]

        # src = haze_I
        # mid = img_dehazed
        # t = T

        aa = mid.copy()
        aa[:, :, 0] = A[:, :, 0]
        aa[:, :, 1] = A[:, :, 1]
        aa[:, :, 2] = A[:, :, 2]

        low = self.transformImage(src)
        mid = self.transformImage(mid)
        t = self.transformImage(t)
        a = self.transformImage(aa)
        return low, mid, t, a

    def __len__(self):
        return int(self.len)

test_len = 79
class DatasetTest(data.Dataset):
    def __init__(self, opt):
        TRoot   = np.array([''])
        # for file in os.listdir(opt.test_root):
        for index in range(1,test_len+1):
            file = str(index)
            TRoot= np.append(TRoot,   opt.test_T + file + '.mat')
        self.TRoot = TRoot[1:]
        self.opt = opt
        self.len=len(self.TRoot)

    def transformImage(self,image):
        opt = self.opt
        image = torchvision.transforms.ToTensor()(image)
        Tensor = torch.FloatTensor if opt.device == 'cpu' else torch.cuda.FloatTensor
        image  = Variable(image.type(Tensor))
        return image

    def __getitem__(self, index):
        mat = sio.loadmat(self.TRoot[index],verify_compressed_data_integrity=False)
        T = mat["t"].astype(np.float64)
        A = (mat["A"]).astype(np.float64)/255.0
        haze_I = mat["haze_I_E_0"].astype(np.float64)/255.0
        img_dehazed = (mat["Dehaze"]).astype(np.float64)/255.0

        aa = haze_I.copy()
        aa[:, :, 0] = A[:, :, 0]
        aa[:, :, 1] = A[:, :, 1]
        aa[:, :, 2] = A[:, :, 2]

        haze_I = self.transformImage(haze_I)
        img_dehazed = self.transformImage(img_dehazed)
        t = self.transformImage(T)
        a = self.transformImage(aa)
        return haze_I, img_dehazed, t, a

    def __len__(self):
        return int(self.len)

