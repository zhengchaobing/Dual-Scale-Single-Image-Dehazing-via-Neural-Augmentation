

import torch
import sys
from torch.autograd import Variable
import numpy as np
from options.train_options import TrainOptions
opt = TrainOptions().parse()  # set CUDA_VISIBLE_DEVICES before import torch
from data.data_loader import CreateDataLoader
from models.models import create_model
from skimage import io
from skimage.transform import resize

import torch
import torch.nn as nn
from torch.nn import Conv2d
import numpy as np
from torch.nn.functional import l1_loss

##########################################################################

def conv(in_channels, out_channels, kernel_size, bias=True, padding=1, stride=1):
    return nn.Conv2d( in_channels, out_channels, kernel_size, padding=(kernel_size // 2), bias=bias, stride=stride)




class ChannelPool(nn.Module):
    def forward(self, x):
        hor, vet = TVLossL1(x)
        return torch.cat((torch.max(hor, 1)[0].unsqueeze(1), torch.max(vet, 1)[0].unsqueeze(1)), dim=1)

class BasicConv(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1, relu=True, bias=False):
        super(BasicConv, self).__init__()
        self.out_channels = out_planes
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding,  dilation=dilation, groups=groups, bias=bias)

    def forward(self, x):
        x = self.conv(x)
        return x

class spatial_attn_layer(nn.Module):
    def __init__(self, kernel_size=3):
        super(spatial_attn_layer, self).__init__()
        self.compress = ChannelPool()
        self.spatial = BasicConv(2, 1, kernel_size, stride=1, padding=(kernel_size - 1) // 2, relu=False)

    def forward(self, x):
        # import pdb;pdb.set_trace()
        x_compress = self.compress(x)
        x_out = self.spatial(x_compress)
        scale = torch.sigmoid(x_out)  # broadcasting
        return x * scale

## Dual Attention Block (DAB)
class DAB(nn.Module):
    def __init__(  self, conv, n_feat, kernel_size, reduction, bias=True, bn=False, act=nn.LeakyReLU(0.2)):
        super(DAB, self).__init__()
        modules_body = []
        for i in range(2):
            modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
            if bn: modules_body.append(nn.BatchNorm2d(n_feat))
            if i == 0: modules_body.append(act)

        self.SA = spatial_attn_layer()  ## Spatial Attention
        self.body = nn.Sequential(*modules_body)
        self.conv1x1 = nn.Conv2d(n_feat, n_feat, kernel_size=1)

    def forward(self, x):
        res = self.body(x)
        sa_branch = self.SA(res)
        res = self.conv1x1(sa_branch)
        res += x
        return res

## Recursive Residual Group (RRG)
class RRG(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction, act, num_dab):
        super(RRG, self).__init__()
        modules_body = []
        modules_body = [DAB(conv, n_feat, kernel_size, reduction, bias=True, bn=False, act=act) for _ in range(num_dab)]
        modules_body.append(conv(n_feat, n_feat, kernel_size))
        self.body = nn.Sequential(*modules_body)

    def forward(self, x):
        res = self.body(x)
        res += x
        return res


class DenoiseNet(nn.Module):
    def __init__(self, conv=conv):
        super(DenoiseNet, self).__init__()
        num_rrg = 5
        num_dab = 2
        n_feats = 64
        kernel_size = 3
        reduction = 16
        inp_chans = 3
        act = nn.LeakyReLU(0.2)

        modules_head = [conv(3, n_feats, kernel_size=kernel_size, stride=1)]
        modules_body = [RRG(conv, n_feats, kernel_size, reduction, act=act, num_dab=num_dab)  for _ in range(num_rrg)]
        modules_body.append(conv(n_feats, n_feats, kernel_size))
        modules_body.append(act)
        modules_tail = [conv(n_feats, inp_chans, kernel_size)]

        self.head = nn.Sequential(*modules_head)
        self.body = nn.Sequential(*modules_body)
        self.tail = nn.Sequential(*modules_tail)



    def forward(self,t):
        x1 = self.head(t)
        x2 = self.body(x1)
        y = self.tail(x2) + t
        T = torch.clamp(y, 0.1, 1.0)
        return T


if __name__ == '__main__':


    img = torch.randn(5, 3, 256, 256)
    img2 = Variable(img.cuda())
    tvloss1, tvloss2 = TVLossL1(img2)

    print(tvloss1.size())

    net3 = DenoiseNet().cuda()
    out = net3(img2)
    print(out.size())

    # AA = torch.max(img, 2)[0].unsqueeze(2)
    # print(AA.size())
    #
    # BB = torch.max(img, 3)[0].unsqueeze(3)
    # print(BB.size())


    CC = 1;

