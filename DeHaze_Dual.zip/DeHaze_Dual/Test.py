# python相关
import os
import warnings
# pytorh相关
import torch
from torch.utils import data
from skimage.metrics import peak_signal_noise_ratio as compare_psnr
from skimage.metrics import structural_similarity as compare_ssim
import numpy as np
# 自定义类
from config import get_arguments
import Dataset
import SavePicture

import skimage
#忽视警告
warnings.filterwarnings("ignore")

# 导入参数设置
parser = get_arguments()
opt = parser.parse_args()

torch.manual_seed(opt.seed)
if opt.cuda:
    torch.cuda.manual_seed(opt.seed)
#并行训练相关设置
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device=torch.device("cuda:0")

#读取数据集

test_dataset  = Dataset.DatasetTest(opt)
batch_test  = 1
test_loader  = data.DataLoader(dataset=test_dataset,  batch_size=batch_test,  shuffle=False,)


model_path = "checkpoint/{}/netG_model_epoch_{}.pth".format(opt.dataset, opt.nepochs)
model_restoration = torch.load(model_path).to(device)

model_restoration.eval()
with torch.no_grad():
    avg_psnr = 0.0; avg_ssim=0.0
    for idx, (haze, dehaze, t, A) in enumerate(test_loader):
        print(idx)
        img_dehazy =torch.clamp(  model_restoration(haze, A, t), 0.00, 1.0)

        img0 = img_dehazy[0, :, :, :].clone()
        img0[0, :, :] = img_dehazy[0, 2, :, :]
        img0[2, :, :] = img_dehazy[0, 0, :, :]

        img1 = dehaze[0, :, :, :].clone()
        img1[0, :, :] = dehaze[0, 2, :, :]
        img1[2, :, :] = dehaze[0, 0, :, :]

        SavePicture.save_from_tensor_test(img0 * 255.0,'./Results/' + str(idx+1) +'_'+str(opt.nepochs) + '.png')

        img0=img0.float().cpu().numpy()
        img1=img1.float().cpu().numpy()
        img22 = np.transpose(img0, (1, 2, 0))
        img00 = np.transpose(img1, (1, 2, 0))
        psnr = compare_psnr(img0, img1, data_range=1.0)
        avg_psnr += psnr
        ssim = compare_ssim(img22, img00, data_range=1.0, multichannel=True)
        avg_ssim += ssim
    print("===> Avg. PSNR: {:.6f} dB".format(avg_psnr / len(test_loader)))





