

input_file    = 'G:\A_Paper_DeHaze\TestData79\Imgs\4.jpg';
ouput_file   = 'G:\A_Paper_DeHaze\TestData79\Imgs\4.jpg';
ouput_Mat = '1.mat';
mytest(input_file, ouput_file,21,  ouput_Mat)